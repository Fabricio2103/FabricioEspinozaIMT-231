#!/bin/bash

# Mostrar el directorio actual
pwd

# Acceder a la carpeta /tmp y listar su contenido
cd /tmp
ls

# Volver al directorio personal
cd ~

# Crear una carpeta llamada practica_shell
mkdir practica_shell

# Acceder a practica_shell
cd practica_shell

# Mostrar el directorio actual
pwd
