#!/bin/bash

# Pedir al usuario su nombre
echo "Por favor, ingresa tu nombre:"
read nombre

# Saludar al usuario
echo "Hola, $nombre. ¡Bienvenido!"

# Imprimir el contenido del script.sh en la terminal
echo "El contenido de este script es:"
cat $0
